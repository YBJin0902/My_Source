#ifndef _LORA_H_
#define _LORA_H_

extern void LoRa_INIT();
extern void PrintLoRa(unsigned char []);
void printLoRa(uint8_t []);

#endif